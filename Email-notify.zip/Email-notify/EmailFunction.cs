using System;
using System.Net;
using System.Net.Mail;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;

namespace ust.trainingproject
{
    public class EmailFunction
    {
        private readonly ILogger<EmailFunction> _logger;

        public EmailFunction(ILogger<EmailFunction> logger)
        {
            _logger = logger;
        }

        [Function("EmailFunction")]
        public IActionResult Run([HttpTrigger(AuthorizationLevel.Anonymous, "get", "post")] HttpRequest req)
        {
            _logger.LogInformation("C# HTTP trigger function processed a request.");
            bool result = SendMail();
            if (result)
                return new OkObjectResult("Email sent successfully");
            return new OkObjectResult("Unable to send email");
        }
        public bool SendMail()
        {
            var mailMessage = new MailMessage
            {
                From = new MailAddress("ushabh42@gmail.com"),
                Subject = "Thank you for your request",
                Body = "We are glad to receive the application from UST",
                IsBodyHtml = false // Set to true if your email body contains HTML
            };
            mailMessage.To.Add("usha.bh@ust.com");

            using var smtpClient = new SmtpClient("smtp.gmail.com", 587) // Use port 587 for explicit SSL
            {
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential("ushabh42@gmail.com", "szkt yngg mjku elhe"), // Replace with your App Password
                EnableSsl = true
            };

            try
            {
                smtpClient.Send(mailMessage);
                _logger.LogInformation("Email sent successfully!");
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to send email: {ex.Message}");
                return false;
            }
        }
    }
}